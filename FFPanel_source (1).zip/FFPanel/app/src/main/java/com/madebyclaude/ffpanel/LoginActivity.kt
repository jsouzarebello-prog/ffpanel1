package com.madebyclaude.ffpanel

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        prefs = getSharedPreferences("ffpanel_prefs", MODE_PRIVATE)

        if (prefs.getBoolean("logged_in", false)) {
            goToPanel()
            return
        }

        val userField = findViewById<EditText>(R.id.editUser)
        val keyField = findViewById<EditText>(R.id.editKey)
        val loginBtn = findViewById<Button>(R.id.btnLogin)
        val errorText = findViewById<TextView>(R.id.textError)

        loginBtn.setOnClickListener {
            val user = userField.text.toString()
            val key = keyField.text.toString()

            if (AuthConfig.check(user, key)) {
                prefs.edit().putBoolean("logged_in", true).apply()
                goToPanel()
            } else {
                errorText.text = "Usuário ou key inválidos."
                errorText.visibility = TextView.VISIBLE
            }
        }
    }

    private fun goToPanel() {
        startActivity(Intent(this, PanelActivity::class.java))
        finish()
    }
}
