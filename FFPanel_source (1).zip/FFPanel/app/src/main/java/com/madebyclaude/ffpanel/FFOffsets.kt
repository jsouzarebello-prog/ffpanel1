package com.madebyclaude.ffpanel

/**
 * Offsets portados do arquivo fornecido (offsets.h). Mesmos valores,
 * só convertidos pra Kotlin/Long.
 */
object FFOffsets {
    const val InitBase = 0xA342EFCL

    const val StaticClass = 0x5CL
    const val CurrentMatch = 0x50L
    const val CurrentMatchGame = 0x4L
    const val MatchStatus = 0x8CL
    const val LocalPlayer = 0x94L
    const val DictionaryEntities = 0x68L

    const val Player_IsDead = 0x50L
    const val Player_Data = 0x48L
    const val IsClientBot = 0x324L
    const val TeamModeID = 0x294L
    const val XPose = 0x78L // ponteiro pro transform/posição do player

    const val MainCameraTransform = 0x28CL
    const val FollowCamera = 0x494L
    const val LockedAimingCollider = 0x54L
    const val Collider = 0x4E8L
    const val AimRotation = 0x440L

    object Bones {
        const val Head = 0x49CL
    }

    // ===== Rapid fire / no recoil =====
    const val Player_WeaponFireComponent = 0x8FCL
    const val WeaponFireComponent_FireInterval = 0x120L
    const val NoRecoilFlag = 0x548L

    // ===== Layout genérico de Dictionary<int, IntPtr> do IL2CPP =====
    // Esses três não vieram no arquivo que você mandou — são o padrão mais
    // comum em runtimes IL2CPP de 64-bit, mas variam por versão do Unity.
    // FILL: confirma com o scanner (acha o ponteiro de DictionaryEntities,
    // olha os primeiros bytes: se Count bater com o número de players
    // vivos na partida, os offsets abaixo estão certos; se não, ajusta).
    const val Dict_Entries = 0x18L   // FILL: ponteiro pro array de entries
    const val Dict_Count = 0x20L     // FILL: int com a quantidade de entries
    const val DictEntry_Stride = 0x18L // FILL: tamanho de cada struct Entry
    const val DictEntry_Value = 0x10L  // FILL: offset do value (IntPtr) dentro do Entry
}
