package com.madebyclaude.ffpanel

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Scanner
import kotlin.math.atan2
import kotlin.math.sqrt

/**
 * Roda no processo privilegiado criado pelo Shizuku (UID shell, ou maior
 * dependendo de como o Shizuku foi iniciado). Lê/escreve /proc/pid/mem
 * diretamente e escaneia regiões de memória por valor.
 */
class MemoryUserService : IMemoryService.Stub() {

    override fun findProcessId(packageName: String): Int {
        val procDir = File("/proc")
        val pids = procDir.listFiles { f -> f.name.matches(Regex("\\d+")) } ?: return -1
        for (pidDir in pids) {
            try {
                val cmdline = File(pidDir, "cmdline").readText().trim('\u0000')
                if (cmdline == packageName) {
                    return pidDir.name.toInt()
                }
            } catch (_: Exception) {
                // processo pode ter morrido entre o list e a leitura
            }
        }
        return -1
    }

    override fun readMemory(pid: Int, address: Long, size: Int): ByteArray {
        return try {
            RandomAccessFile("/proc/$pid/mem", "r").use { raf ->
                raf.seek(address)
                val buf = ByteArray(size)
                raf.readFully(buf)
                buf
            }
        } catch (e: Exception) {
            ByteArray(0)
        }
    }

    override fun writeMemory(pid: Int, address: Long, data: ByteArray): Boolean {
        return try {
            RandomAccessFile("/proc/$pid/mem", "rw").use { raf ->
                raf.seek(address)
                raf.write(data)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Lista as regiões de memória RW do processo (de /proc/pid/maps),
     * ignorando libs do sistema e regiões não graváveis — é nelas que
     * ficam os dados de gameplay (heap, anon).
     */
    fun listScannableRegions(pid: Int): List<MemRegion> {
        val regions = mutableListOf<MemRegion>()
        try {
            Scanner(File("/proc/$pid/maps")).use { sc ->
                while (sc.hasNextLine()) {
                    val line = sc.nextLine()
                    val parts = line.split(Regex("\\s+"))
                    if (parts.size < 2) continue
                    val perms = parts[1]
                    if (!perms.startsWith("rw")) continue
                    // Foca em heap e regiões anônimas (sem path de .so/.dll),
                    // que é onde o estado de jogo (não-código) vive.
                    val path = parts.getOrNull(5) ?: ""
                    if (path.isNotBlank() && !path.contains("[heap]") && !path.contains("[anon")) continue

                    val range = parts[0].split("-")
                    val start = range[0].toLong(16)
                    val end = range[1].toLong(16)
                    regions.add(MemRegion(start, end))
                }
            }
        } catch (_: Exception) {
        }
        return regions
    }

    /**
     * Primeira passada: varre as regiões gravável/heap procurando um int32
     * igual a 'value'. Retorna todos os endereços candidatos.
     */
    override fun scanInt(pid: Int, value: Int): LongArray {
        return scanIntInternal(pid, value).toLongArray()
    }

    private fun scanIntInternal(pid: Int, value: Int): List<Long> {
        val target = intToBytes(value)
        val matches = mutableListOf<Long>()
        val chunkSize = 1 shl 20 // 1MB por leitura

        for (region in listScannableRegions(pid)) {
            var addr = region.start
            while (addr < region.end) {
                val toRead = minOf(chunkSize.toLong(), region.end - addr).toInt()
                val buf = readMemory(pid, addr, toRead)
                if (buf.isEmpty()) {
                    addr += toRead
                    continue
                }
                var i = 0
                while (i <= buf.size - 4) {
                    if (buf[i] == target[0] && buf[i + 1] == target[1] &&
                        buf[i + 2] == target[2] && buf[i + 3] == target[3]
                    ) {
                        matches.add(addr + i)
                    }
                    i++
                }
                addr += toRead
            }
        }
        return matches
    }

    /**
     * Segunda passada em diante: filtra uma lista de candidatos, mantendo
     * só os que ainda têm 'newValue' agora. Use depois de fazer uma ação
     * no jogo que mude o valor de forma conhecida (ex: tomar dano).
     */
    override fun refineInt(pid: Int, candidates: LongArray, newValue: Int): LongArray {
        val target = intToBytes(newValue)
        return candidates.filter { addr ->
            val buf = readMemory(pid, addr, 4)
            buf.size == 4 && buf[0] == target[0] && buf[1] == target[1] &&
                buf[2] == target[2] && buf[3] == target[3]
        }.toLongArray()
    }

    private fun intToBytes(v: Int): ByteArray = byteArrayOf(
        (v and 0xFF).toByte(),
        ((v shr 8) and 0xFF).toByte(),
        ((v shr 16) and 0xFF).toByte(),
        ((v shr 24) and 0xFF).toByte()
    )

    // ===== Leitura tipada =====

    private fun readPtr(pid: Int, address: Long): Long {
        val buf = readMemory(pid, address, 8)
        if (buf.size < 8) return 0L
        return ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN).long
    }

    private fun readInt(pid: Int, address: Long): Int {
        val buf = readMemory(pid, address, 4)
        if (buf.size < 4) return 0
        return ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN).int
    }

    private fun readFloat(pid: Int, address: Long): Float {
        val buf = readMemory(pid, address, 4)
        if (buf.size < 4) return 0f
        return ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN).float
    }

    private data class Vec3(val x: Float, val y: Float, val z: Float)

    private fun readVec3(pid: Int, address: Long): Vec3 {
        val buf = readMemory(pid, address, 12)
        if (buf.size < 12) return Vec3(0f, 0f, 0f)
        val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
        return Vec3(bb.float, bb.float, bb.float)
    }

    // ===== Módulo base =====

    override fun findModuleBase(pid: Int, moduleName: String): Long {
        try {
            File("/proc/$pid/maps").forEachLine { line ->
                if (line.contains(moduleName)) {
                    val start = line.substringBefore("-").toLong(16)
                    return start
                }
            }
        } catch (_: Exception) {
        }
        return 0L
    }

    // ===== Cadeia de ponteiros + aim =====

    private data class EntityInfo(val ptr: Long, val pos: Vec3, val isDead: Boolean, val team: Int)

    private fun resolveLocalPlayerAndMatch(pid: Int, il2cppBase: Long): Triple<Long, Long, Int>? {
        // base -> ponteiro estático -> StaticClass -> CurrentMatch -> CurrentMatchGame
        val staticFieldsPtr = readPtr(pid, il2cppBase + FFOffsets.InitBase)
        if (staticFieldsPtr == 0L) return null
        val staticClass = readPtr(pid, staticFieldsPtr + FFOffsets.StaticClass)
        if (staticClass == 0L) return null
        val currentMatch = readPtr(pid, staticClass + FFOffsets.CurrentMatch)
        if (currentMatch == 0L) return null
        val currentMatchGame = readPtr(pid, currentMatch + FFOffsets.CurrentMatchGame)
        if (currentMatchGame == 0L) return null

        val localPlayer = readPtr(pid, currentMatchGame + FFOffsets.LocalPlayer)
        val localTeam = if (localPlayer != 0L) readInt(pid, localPlayer + FFOffsets.TeamModeID) else -1

        return Triple(currentMatchGame, localPlayer, localTeam)
    }

    private fun readEntityPosition(pid: Int, entityPtr: Long): Vec3 {
        val transformPtr = readPtr(pid, entityPtr + FFOffsets.XPose)
        if (transformPtr == 0L) return Vec3(0f, 0f, 0f)
        // Bones.Head é relativo ao mesmo transform/skeleton pointer.
        return readVec3(pid, transformPtr + FFOffsets.Bones.Head)
    }

    /**
     * Itera a Dictionary<int, IntPtr> de entidades usando o layout genérico
     * marcado como FILL em FFOffsets. Se os offsets de dicionário estiverem
     * errados pra essa build, isso retorna lista vazia ou lixo — valida com
     * o scanner antes (ver nota em FFOffsets).
     */
    private fun iterateEntities(pid: Int, matchGame: Long): List<Long> {
        val dictPtr = readPtr(pid, matchGame + FFOffsets.DictionaryEntities)
        if (dictPtr == 0L) return emptyList()

        val entriesPtr = readPtr(pid, dictPtr + FFOffsets.Dict_Entries)
        val count = readInt(pid, dictPtr + FFOffsets.Dict_Count)
        if (entriesPtr == 0L || count <= 0 || count > 200) return emptyList()

        val result = mutableListOf<Long>()
        for (i in 0 until count) {
            val entryAddr = entriesPtr + i * FFOffsets.DictEntry_Stride
            val value = readPtr(pid, entryAddr + FFOffsets.DictEntry_Value)
            if (value != 0L) result.add(value)
        }
        return result
    }

    @Volatile private var aimLoopRunning = false
    private var aimThread: Thread? = null

    @Volatile private var predictiveEnabled = false
    @Volatile private var projectileSpeed = 550f // m/s aprox.; ajusta por arma se quiser precisão maior
    private val lastSeen = java.util.concurrent.ConcurrentHashMap<Long, Pair<Vec3, Long>>()

    override fun setPredictiveAim(enabled: Boolean, projSpeed: Float) {
        predictiveEnabled = enabled
        if (projSpeed > 0f) projectileSpeed = projSpeed
        if (!enabled) lastSeen.clear()
    }

    /**
     * Estima velocidade do alvo a partir de duas amostras de posição e
     * projeta pra frente o tempo que o projétil levaria pra chegar
     * (distância / projectileSpeed). Isso dá o ponto de mira "onde ele vai
     * estar", não onde ele tá agora.
     */
    private fun predictPosition(entityPtr: Long, currentPos: Vec3, localPos: Vec3): Vec3 {
        val now = System.currentTimeMillis()
        val prev = lastSeen[entityPtr]
        lastSeen[entityPtr] = Pair(currentPos, now)

        if (prev == null) return currentPos
        val dt = (now - prev.second) / 1000f
        if (dt <= 0f || dt > 0.5f) return currentPos // amostra velha demais, não confia

        val vx = (currentPos.x - prev.first.x) / dt
        val vy = (currentPos.y - prev.first.y) / dt
        val vz = (currentPos.z - prev.first.z) / dt

        val dx = currentPos.x - localPos.x
        val dy = currentPos.y - localPos.y
        val dz = currentPos.z - localPos.z
        val dist = sqrt(dx * dx + dy * dy + dz * dz)
        val travelTime = dist / projectileSpeed

        return Vec3(
            currentPos.x + vx * travelTime,
            currentPos.y + vy * travelTime,
            currentPos.z + vz * travelTime
        )
    }

    override fun aimAtNearestOnce(pid: Int, il2cppBase: Long): Boolean {
        val (matchGame, localPlayer, localTeam) = resolveLocalPlayerAndMatch(pid, il2cppBase) ?: return false
        if (localPlayer == 0L) return false

        val localPos = readEntityPosition(pid, localPlayer)
        val entities = iterateEntities(pid, matchGame)

        var nearest: Long? = null
        var nearestDist = Float.MAX_VALUE
        var nearestPos = Vec3(0f, 0f, 0f)

        for (entityPtr in entities) {
            if (entityPtr == localPlayer) continue
            val isDead = readInt(pid, entityPtr + FFOffsets.Player_IsDead) != 0
            if (isDead) continue
            val team = readInt(pid, entityPtr + FFOffsets.TeamModeID)
            if (team == localTeam) continue // mesmo time, ignora

            val pos = readEntityPosition(pid, entityPtr)
            val dx = pos.x - localPos.x
            val dy = pos.y - localPos.y
            val dz = pos.z - localPos.z
            val dist = sqrt(dx * dx + dy * dy + dz * dz)
            if (dist < nearestDist) {
                nearestDist = dist
                nearest = entityPtr
                nearestPos = pos
            }
        }

        val target = nearest ?: return false

        // Silent aim: trava o collider de mira do jogo local no alvo achado
        // (padrão desse cheat: LockedAimingCollider / Collider em FollowCamera),
        // sem mexer no ângulo visível da câmera do usuário.
        val followCamera = readPtr(pid, localPlayer + FFOffsets.FollowCamera)
        if (followCamera != 0L) {
            val colliderOfTarget = readPtr(pid, target + FFOffsets.Collider)
            if (colliderOfTarget != 0L) {
                val ok = writeMemory(
                    pid,
                    followCamera + FFOffsets.LockedAimingCollider,
                    longToBytes(colliderOfTarget)
                )
                if (ok) return true
            }
        }

        // Fallback: escreve diretamente o ângulo calculado no AimRotation,
        // caso o collider lock não esteja disponível nessa versão.
        val yaw = atan2(nearestPos.x - localPos.x, nearestPos.z - localPos.z)
        return writeMemory(pid, localPlayer + FFOffsets.AimRotation, floatToBytes(yaw))
    }

    /**
     * Rapid fire: zera o intervalo entre tiros. RapidfirePtr/FireInterval
     * (0x1C8) é relativo à struct PlayerAttributes do player local (0x500),
     * conforme o agrupamento no arquivo de offsets que você mandou.
     */
    override fun setRapidFire(pid: Int, il2cppBase: Long, enable: Boolean): Boolean {
        val (_, localPlayer, _) = resolveLocalPlayerAndMatch(pid, il2cppBase) ?: return false
        if (localPlayer == 0L) return false
        val attrs = readPtr(pid, localPlayer + FFOffsets.PlayerAttributes)
        if (attrs == 0L) return false
        val value = if (enable) 0.001f else 0.15f // 0.15 ~ cadência padrão; ajusta se destoar
        return writeMemory(pid, attrs + FFOffsets.FireInterval, floatToBytes(value))
    }

    /**
     * No recoil: zera o flag/escala de recuo. Mesma estrutura de
     * PlayerAttributes; NoRecoilFlag como byte (0/1) — se essa build tratar
     * como float de escala em vez de bool, troca pra floatToBytes(0f).
     */
    override fun setNoRecoil(pid: Int, il2cppBase: Long, enable: Boolean): Boolean {
        val (_, localPlayer, _) = resolveLocalPlayerAndMatch(pid, il2cppBase) ?: return false
        if (localPlayer == 0L) return false
        val attrs = readPtr(pid, localPlayer + FFOffsets.PlayerAttributes)
        if (attrs == 0L) return false
        return writeMemory(pid, attrs + FFOffsets.NoRecoilFlag, byteArrayOf(if (enable) 1 else 0))
    }

    override fun startAimLoop(pid: Int, il2cppBase: Long, intervalMs: Int) {
        if (aimLoopRunning) return
        aimLoopRunning = true
        aimThread = Thread {
            while (aimLoopRunning) {
                try {
                    aimAtNearestOnce(pid, il2cppBase)
                } catch (_: Exception) {
                }
                Thread.sleep(intervalMs.toLong().coerceAtLeast(16))
            }
        }
        aimThread?.start()
    }

    override fun stopAimLoop() {
        aimLoopRunning = false
        aimThread?.join(500)
        aimThread = null
    }

    private fun longToBytes(v: Long): ByteArray =
        ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(v).array()

    private fun floatToBytes(v: Float): ByteArray =
        ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(v).array()

    override fun destroy() {
        stopAimLoop()
        System.exit(0)
    }

    data class MemRegion(val start: Long, val end: Long)
}
