package com.madebyclaude.ffpanel;

interface IMemoryService {
    // Retorna o PID do processo pelo nome do pacote, ou -1 se não achar
    int findProcessId(String packageName);

    // Lê 'size' bytes de /proc/pid/mem a partir de 'address'
    byte[] readMemory(int pid, long address, int size);

    // Escreve 'data' em /proc/pid/mem a partir de 'address'. Retorna sucesso.
    boolean writeMemory(int pid, long address, in byte[] data);

    // Varre regiões rw/heap/anon do processo por um int32 == value.
    // Retorna os endereços candidatos (pode ser uma lista grande).
    long[] scanInt(int pid, int value);

    // Filtra 'candidates', mantendo só os que agora valem 'newValue'.
    long[] refineInt(int pid, in long[] candidates, int newValue);

    // Acha a base de um módulo carregado (ex: "libil2cpp.so") em /proc/pid/maps.
    // Retorna 0 se não achar.
    long findModuleBase(int pid, String moduleName);

    // Roda a cadeia de ponteiros até o player local, varre a dictionary de
    // entidades, acha o inimigo vivo mais próximo e escreve o ângulo de
    // mira. Retorna true se achou e escreveu um alvo.
    boolean aimAtNearestOnce(int pid, long il2cppBase);

    // Inicia um loop em background chamando aimAtNearestOnce a cada
    // intervalMs. Chamar stopAimLoop() pra parar.
    void startAimLoop(int pid, long il2cppBase, int intervalMs);
    void stopAimLoop();

    // Liga/desliga rapid fire e no-recoil no player local atual.
    boolean setRapidFire(int pid, long il2cppBase, boolean enable);
    boolean setNoRecoil(int pid, long il2cppBase, boolean enable);

    // true = usa predição de movimento (lead) em vez de colar na hitbox atual.
    void setPredictiveAim(boolean enabled, float projectileSpeed);

    void destroy();
}
