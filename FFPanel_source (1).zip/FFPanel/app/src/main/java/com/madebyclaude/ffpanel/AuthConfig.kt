package com.madebyclaude.ffpanel

object AuthConfig {
    const val VALID_USER = "JoséBonitão"
    const val VALID_KEY = "JoseDoGrau"

    fun check(user: String, key: String): Boolean {
        return user.trim() == VALID_USER && key.trim() == VALID_KEY
    }
}
