package com.madebyclaude.ffpanel

import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import rikka.shizuku.Shizuku

class PanelActivity : AppCompatActivity() {

    private var memoryService: IMemoryService? = null
    private var currentPid: Int = -1
    private var lastCandidates: List<Long> = emptyList()
    private var aimActive = false
    private var rapidActive = false
    private var noRecoilActive = false
    private var cachedIl2cppBase: Long = 0L

    private lateinit var textStatus: TextView
    private lateinit var textPid: TextView
    private lateinit var textResults: TextView
    private lateinit var editScanValue: EditText

    companion object {
        private const val SHIZUKU_PERMISSION_CODE = 1001
        private const val TARGET_PACKAGE = "com.dts.freefireth"
    }

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, grantResult ->
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
            bindUserService()
            textStatus.text = "Shizuku: permissão concedida"
        } else {
            textStatus.text = "Shizuku: permissão negada"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_panel)

        textStatus = findViewById(R.id.textShizukuStatus)
        textPid = findViewById(R.id.textPid)
        textResults = findViewById(R.id.textResults)
        editScanValue = findViewById(R.id.editScanValue)

        findViewById<Button>(R.id.btnRequestPermission).setOnClickListener {
            requestShizukuPermission()
        }
        findViewById<Button>(R.id.btnFindProcess).setOnClickListener {
            findProcess()
        }
        findViewById<Button>(R.id.btnScan).setOnClickListener {
            doScan()
        }
        findViewById<Button>(R.id.btnRefine).setOnClickListener {
            doRefine()
        }
        findViewById<Button>(R.id.btnToggleAim).setOnClickListener {
            toggleAim(it as Button)
        }
        findViewById<Button>(R.id.btnToggleRapid).setOnClickListener {
            toggleRapidFire(it as Button)
        }
        findViewById<Button>(R.id.btnToggleRecoil).setOnClickListener {
            toggleNoRecoil(it as Button)
        }

        Shizuku.addRequestPermissionResultListener(permissionListener)
        checkShizukuStatus()
    }

    private fun checkShizukuStatus() {
        if (!Shizuku.pingBinder()) {
            textStatus.text = "Shizuku: serviço não está rodando (abre o app Shizuku e ativa)"
            return
        }
        if (Shizuku.isPreV11()) {
            textStatus.text = "Shizuku: versão antiga, atualiza o app Shizuku"
            return
        }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            textStatus.text = "Shizuku: pronto"
            bindUserService()
        } else {
            textStatus.text = "Shizuku: precisa de permissão"
        }
    }

    private fun requestShizukuPermission() {
        if (!Shizuku.pingBinder()) {
            textStatus.text = "Abre o app Shizuku primeiro e ativa o serviço"
            return
        }
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            bindUserService()
            return
        }
        Shizuku.requestPermission(SHIZUKU_PERMISSION_CODE)
    }

    private fun bindUserService() {
        val args = Shizuku.UserServiceArgs(
            ComponentName(packageName, MemoryUserService::class.java.name)
        )
            .daemon(false)
            .processNameSuffix("memsvc")
            .debuggable(false)
            .version(1)

        Shizuku.bindUserService(args, object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                memoryService = IMemoryService.Stub.asInterface(service)
                textStatus.text = "Shizuku: serviço conectado"
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                memoryService = null
                textStatus.text = "Shizuku: serviço desconectado"
            }
        })
    }

    private fun findProcess() {
        val svc = memoryService
        if (svc == null) {
            textStatus.text = "Serviço não conectado ainda"
            return
        }
        currentPid = svc.findProcessId(TARGET_PACKAGE)
        textPid.text = "PID: ${if (currentPid > 0) currentPid else "não encontrado (jogo aberto?)"}"
    }

    private fun doScan() {
        val svc = memoryService ?: return
        if (currentPid <= 0) {
            textResults.text = "Acha o processo primeiro."
            return
        }
        val value = editScanValue.text.toString().toIntOrNull() ?: return
        Thread {
            val results = svc.scanInt(currentPid, value)?.toList() ?: emptyList()
            lastCandidates = results
            runOnUiThread {
                textResults.text = "Candidatos (${results.size}):\n" +
                    results.take(50).joinToString("\n") { "0x${it.toString(16)}" }
            }
        }.start()
    }

    private fun doRefine() {
        val svc = memoryService ?: return
        if (lastCandidates.isEmpty()) {
            textResults.text = "Faz um scan primeiro."
            return
        }
        val value = editScanValue.text.toString().toIntOrNull() ?: return
        Thread {
            val results = svc.refineInt(currentPid, lastCandidates.toLongArray(), value)?.toList() ?: emptyList()
            lastCandidates = results
            runOnUiThread {
                textResults.text = "Após refinar (${results.size}):\n" +
                    results.joinToString("\n") { "0x${it.toString(16)}" }
            }
        }.start()
    }

    private fun toggleAim(button: Button) {
        val svc = memoryService ?: return
        if (currentPid <= 0) {
            textResults.text = "Acha o processo primeiro."
            return
        }
        if (!aimActive) {
            Thread {
                val base = resolveIl2cppBase(svc) ?: return@Thread
                svc.startAimLoop(currentPid, base, 50)
                aimActive = true
                runOnUiThread {
                    button.text = "Desligar Silent Aim"
                    textResults.text = "Silent aim ativo (base 0x${base.toString(16)})"
                }
            }.start()
        } else {
            svc.stopAimLoop()
            aimActive = false
            button.text = "Ligar Silent Aim"
            textResults.text = "Silent aim desligado"
        }
    }

    private fun resolveIl2cppBase(svc: IMemoryService): Long? {
        if (cachedIl2cppBase != 0L) return cachedIl2cppBase
        val base = svc.findModuleBase(currentPid, "libil2cpp.so")
        if (base == 0L) {
            runOnUiThread { textResults.text = "libil2cpp.so não encontrado — jogo carregou?" }
            return null
        }
        cachedIl2cppBase = base
        return base
    }

    private fun toggleRapidFire(button: Button) {
        val svc = memoryService ?: return
        if (currentPid <= 0) {
            textResults.text = "Acha o processo primeiro."
            return
        }
        Thread {
            val base = resolveIl2cppBase(svc) ?: return@Thread
            val newState = !rapidActive
            val ok = svc.setRapidFire(currentPid, base, newState)
            if (ok) rapidActive = newState
            runOnUiThread {
                button.text = if (rapidActive) "Desligar Rapid Fire" else "Ligar Rapid Fire"
                textResults.text = if (ok) "Rapid fire: $rapidActive" else "Falhou — player local não resolvido"
            }
        }.start()
    }

    private fun toggleNoRecoil(button: Button) {
        val svc = memoryService ?: return
        if (currentPid <= 0) {
            textResults.text = "Acha o processo primeiro."
            return
        }
        Thread {
            val base = resolveIl2cppBase(svc) ?: return@Thread
            val newState = !noRecoilActive
            val ok = svc.setNoRecoil(currentPid, base, newState)
            if (ok) noRecoilActive = newState
            runOnUiThread {
                button.text = if (noRecoilActive) "Desligar No Recoil" else "Ligar No Recoil"
                textResults.text = if (ok) "No recoil: $noRecoilActive" else "Falhou — player local não resolvido"
            }
        }.start()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        if (aimActive) memoryService?.stopAimLoop()
        super.onDestroy()
    }
}
